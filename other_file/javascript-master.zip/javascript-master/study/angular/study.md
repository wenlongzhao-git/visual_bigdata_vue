#### angular8
```js
    this.formGroup.get(item).valueChanges.subscribe()
    ng-model-options="{updateOn: 'change'}"
    (ngModelChange)="requiredChange($event)"
```
