## 手写源码系列

#### Promise

[手写Promise](./promise.js)

>
  参考文献
  [Promise](https://github.com/then/promise)
  [asap](https://github.com/kriskowal/asap)
>

#### 