export default {
    addBook(context, payload) {
      context.commit('addBook', payload);
    },
};