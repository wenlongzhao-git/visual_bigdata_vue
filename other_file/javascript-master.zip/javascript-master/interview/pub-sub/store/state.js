export default {
    bookList: [],
};