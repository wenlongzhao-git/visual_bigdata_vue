#### RN
    1.React中怎么绑定事件？
    2.父组件传递的属性变化时怎么监听？
    3.什么是受控组件，什么被控制，被谁控制？
    4.redux中connect函数的作用？
    5.简要说下redux的数据流
#### react 
>
  1. 垂直水平居中一个不定宽高的元素,
  2. 清除浮动的方法
  3. js数据类型，如何检测数据类型
  
  4. 数组去重,统计数组元素重复的个数
  5. 
     ```js
        async function test(){
            await console.log(1)
            setTimeOut(()=>console.log(2),0)
            new Promise((resolve)=>{
                console.log(3)
                resolve()
            }).then(()=>{console.log(4)})
            console.log(5)
        }
        test()
    ```   
  6. react事件如何绑定，怎么指向this？
  7. react-router怎么做路由拦截？
  8. react 里面什么叫受控组件与派生状态？
  9. redux connect函数作用？
  10. webpack 怎么加载一个less文件？
  11. git 有两个分支feature1，feature2，想要写在feature1的代码错误的写在了feature2，怎么操作？
>