## 51有色技术栈

#### 前端基础
html(5),css(3),JavaScript(ES6+)
#### 运营管理后台 权限管理
React,node(koa,express),Redux(dva),css-modules
#### 官网(lan360，51youse)
nextjs,React,node(koa,express),mobx
#### 移动端(app)
react-native(需要具备ios，Android原生能力)
#### 基础架构
webpack(框架搭建),
react-router(路由管理),
fetch,axios(数据请求)
Redux(dva),mobx,(全局状态管理)
node(router),npm(包管理)
git(branch管理)
#### 拓展(近期不要求)
vue2,
小程序(taro)
flutter(dart)()