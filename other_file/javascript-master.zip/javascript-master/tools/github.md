#### LibreSSL SSL_connect: SSL_ERROR_SYSCALL in connection to raw.github.com:443
git config --global --unset https.proxy
git config --global --unset http.proxy

$ chsh -s /bin/zsh
$ chsh -s /bin/bash


http://tool.chinaz.com/dns 
修改host
sudo vim /etc/hosts