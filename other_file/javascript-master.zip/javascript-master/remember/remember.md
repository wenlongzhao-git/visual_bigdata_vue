#### 蓝灯
https://www.getlantern.org/en_US/
https://github.com/getlantern/lantern

#### 函数式编程
https://gitlore.com/subject/28/ch2.md

#### 17f634ccdb36084b11557c6ce12d036047a1aa15

wireshark

permission denied
chmod -R 777 /Users/Jo/Documents/Shopins/Pods/Target\ Support\ Files/Pods-Shopins/

#### 友链
http://web.coder666.cn:18080/

table-layout:fixed

#### Package libffi was not found in the pkg-config search path
vim ~/.bash_profile
export PKG_CONFIG_PATH="/usr/local/opt/libffi/lib/pkgconfig"
export LDFLAGS="-L/usr/local/opt/libffi/lib" 
source ~/.bash_profile

rm -rf ~/.node-gyp

#### no member named 'Handle' in namespace 'v8' . node-gyp rebuild

#### http-server jsrsasign(签名)
#### package-lock.json encodeURIComponent
"@babel/plugin-proposal-optional-chaining"

#### eruda vconsole

#### babel-plugin-transform-vue-jsx