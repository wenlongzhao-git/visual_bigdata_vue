## 需要学习的

#### 1.前端跨域代理(已完成)

#### 2.面向对象编程(ES5/6)(已完成)

#### 3.JS放大镜效果

#### 函数节流与防抖

#### redux的引入

#### book
[book](http://lucida.me/blog/developer-reading-list/)
深入理解计算机系统
重构 改善既有代码设计

#### ES6 Iterator for of Symbol Reflect
#### ES6 Promise thunk
#### 函数式编程
#### ES6 Symbol class 私有属性 AST
#### webpack import require require.ensure require.context 
#### 装饰器 redux中间件
#### 广度深度搜索，回溯
#### 


[](https://juejin.im/post/5c64d15d6fb9a049d37f9c20)
[100](https://juejin.im/post/5d23e750f265da1b855c7bbe)(https://github.com/mqyqingfeng/Blog)
[native](https://juejin.im/post/5dac5d82e51d45249850cd20)(https://juejin.im/post/5dbebbfa51882524c507fddb)
(https://juejin.im/post/5b94d8965188255c5a0cdc02)
[collection](https://juejin.im/post/5aae076d6fb9a028cc6100a9)
[手写](https://segmentfault.com/a/1190000020703426)
[daily](https://github.com/Advanced-Frontend/Daily-Interview-Question)(https://github.com/shfshanyue/Daily-Question)
[blog](https://github.com/ljianshu/Blog)
[前端精读](https://github.com/dt-fe/weekly)
[前端进阶](https://juejin.im/post/5e7c08bde51d455c4c66ddad)


#### 浏览器缓存与HTTP协议
[缓存](https://segmentfault.com/a/1190000021248694)
[浏览器相关](https://juejin.im/post/5df5bcea6fb9a016091def69)
[综合](https://segmentfault.com/a/1190000021319127)(https://segmentfault.com/u/we452366)

[collection](https://juejin.im/post/5dfef50751882512444027eb#heading-12)


#### 数据结构与算法
[javascript](https://github.com/trekhleb/javascript-algorithms/blob/master/README.zh-CN.md)




## question

#### package.json 与 package.lock.json
#### nodejs 最佳实践
#### 手写ssr
#### react component 与 class
#### graphql
#### 前端测试
#### BFF

#### redux
https://juejin.im/post/5def4831e51d45584b585000

#### js隐式转换 快狗打车
https://juejin.im/post/5d1d60ccf265da1b6e65c036