## Electron
[doc](https://www.electronjs.org/)
[electron-react-boilerplate](https://github.com/electron-react-boilerplate/electron-react-boilerplate)