#### private 推送

{"op":"query","args":["BTCUSDT"]}

[private.position](./private-ws/position.json)
[private.wallet](./private-ws/wallet.json)
[private.order](./private-ws/order.json)
[private.execution](./private-ws/execution.json)