#### 链接形式
https://www.bybit.com/app/exchange/BTCUSD?campaign=XXX&source=XXX&medium=XXX&content=XXX
#### 说明
- 以上url中不能有空格
- 以上url在谷歌浏览器最长不能超过 8198 英文字符(暂不支持中文)。 
- ?前是 官网，反向交易站，m交易站 任意的地址
- ?后有四对以=分隔的键值对
  - = 前面的  campaign source medium content 四个拼写是固定的
  - = 后面的可以自定义，但要有意义。
  - campaign source medium content 这四个可以不同时出现，都不出现则没有追踪
  - campaign source medium content 这四个不能与 之前的 regist_channel 同时出现。
