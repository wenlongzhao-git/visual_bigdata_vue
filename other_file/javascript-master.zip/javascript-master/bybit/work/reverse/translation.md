#### global
返回旧版 backToOld
合约信息 ContractInformation
USDT本位保障金 USDTBasedMargin
币本位保证金 CurrencyBasedMargin
永续合约 PerpetualContracts

#### common
合约名称 ContractName