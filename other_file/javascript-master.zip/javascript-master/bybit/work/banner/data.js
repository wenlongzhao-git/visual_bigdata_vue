[
    {
      "name": "usdt-airdrop", //埋点
      "link": "", //外链
      "imgs": {
        "img768": "/images/banner/768/usdt-airdrop.jpg",
        "img1280": "/images/banner/1280/usdt-airdrop.jpg",
        "img1920": "/images/banner/1920/usdt-airdrop.jpg"
      },

    }
]

[
  {
    name:'', //埋点
    link:'',  //外链
    title:'', //卡片说明banner没有
    img768: "/images/banner/768/usdt-airdrop.jpg",
    img1280: "/images/banner/1280/usdt-airdrop.jpg",
    img1920: "/images/banner/1920/usdt-airdrop.jpg"
  }
]