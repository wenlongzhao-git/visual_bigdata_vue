<template>
  <div class="usdt-airdrop">

  </div>
</template>
<script>
import i18nPageMixin from '~/mixins/i18n-page-mixin';

export default {
  name: 'home',
  mixins: [i18nPageMixin],
  data() {
    return {

    };
  },
  components: {
  },


  methods: {

  },
};
</script>

<style>


@media screen and (min-width: 768px) and (max-width: 1280px) {

}

@media screen and (max-width: 768px) {

}
</style>
