## 常用js函数及兼容性写法收集
<!--常见js函数收集  -->
#### 常见js函数收集[collection](https://github.com/liubin915249126/javascript/blob/master/collecttion/collection.md)

<!--常见js兼容性写法收集  -->
#### 常见js兼容性写法收集[compatible](https://github.com/liubin915249126/javascript/blob/master/collecttion/compatible.md)